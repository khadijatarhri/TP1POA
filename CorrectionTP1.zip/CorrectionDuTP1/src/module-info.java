/**
 * 
 */
/**
 * 
 */
module CorrectionDuTP1 {
	requires java.desktop;
}